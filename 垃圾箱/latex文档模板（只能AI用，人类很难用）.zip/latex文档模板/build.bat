@echo off
chcp 65001 >nul
REM One-click build for Windows (XeLaTeX + BibTeX).
REM Run this file from the project root. Output: build\main.pdf
if not exist build mkdir build

echo [1/4] xelatex ...
xelatex -interaction=nonstopmode -halt-on-error -synctex=1 -output-directory=build main.tex
if errorlevel 1 goto fail

echo [2/4] bibtex ...
bibtex build\main
if errorlevel 1 goto fail

echo [3/4] xelatex ...
xelatex -interaction=nonstopmode -halt-on-error -synctex=1 -output-directory=build main.tex
if errorlevel 1 goto fail

echo [4/4] xelatex ...
xelatex -interaction=nonstopmode -halt-on-error -synctex=1 -output-directory=build main.tex
if errorlevel 1 goto fail

echo Done: build\main.pdf
exit /b 0

:fail
echo Build failed. See build\main.log
exit /b 1
